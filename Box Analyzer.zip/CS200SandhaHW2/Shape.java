                                       /**************************************************************
                                        ***  Project Name : CS 200 Programming Assignment 2 (HW2)  ***
                                        ***  Author       : Seerat Sandha                          ***
                                        ***  Date         : 10/15/2023                             ***
                                        **************************************************************/




public abstract class Shape  // creating abstract class using "abstract" Keyword 
{
    protected double weight;   // declaring a protected field member
    
    public Shape()      // default constructor intialize weight to 0.0
    {
        weight = 0.0;
        

    }
    public Shape(double weight)   // constructor intializes weight to parameter's value 
    { 
        this.weight = weight; 
    }
    
    public void setWeight(double weight)  // setting the weight of the object 
    {
        this.weight = weight;
    }
    
    public double getWeight()    // getting or returning the weight value of the object
    {
        return weight;
    }
}