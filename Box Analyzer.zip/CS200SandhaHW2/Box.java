                                       /**************************************************************
                                        ***  Project Name : CS 200 Programming Assignment 2 (HW2)  ***
                                        ***  Author       : Seerat Sandha                          ***
                                        ***  Date         : 10/15/2023                             ***
                                        **************************************************************/


public class Box extends Shape // using inheritance 
{
    private double length;   // declaring the private instance variables. 
    private double width;
    private double height;
    
    public Box()          // default constructor 
    {
        length=0.0;
        width=0.0;
        height=0.0;
        
    }
    public Box(double length, double width, double height, double weight)  
                                 // constructor to inisitiate the object's instance variables 
    {
        this.length = length;
        this.width= width;  
        this.height= height;
        this.weight = weight;
    }
    
    
    public void setLength(double length)    // setting the value of length to the parameter value. 
    {
        this.length= length;
    }
    public double getLength()               // returning length. 
    {
        return length;
    }
    public void setWidth(double width) // setting the value of width to the parameter value.
    {
        this.width= width;
    }
    public double getWidth()                  // returning width.
    {
        return width;
    }
    public void setHeight(double height)   // setting the value of height to the parameter value.
    {
        this.height= height;
    }
    public double getHeight()                  // returning height. 
    {
        return height;
    }
    // The 5 additional  user-defined methods 
    
    public boolean isACube()  // if length, width and height are the same then cube i.e true and false otherwise
    {
        if(getLength()== getHeight() && getHeight() ==getWidth() && getWidth() == getLength())
        {
            return true;
        }
        else
        {
            return false;
        }
    }    
    public boolean hasASquare() // if one of the length, width and height are the same then square i.e true and false otherwise
    {
        if(getLength()== getHeight() || getHeight() ==getWidth() || getWidth() == getLength())
        {
            return true;
        }
        
        else
        {
            return false;
        }
   }
    public double calculateVolume() // calculating the volume and return as double 
   {
        if(getLength()<0.0 || getWidth() <0.0 || getHeight()<0.0)
        {
            return 0.00;
            //Invalid Result: The volume cannot be negative
            
        }
        
        double volume = getLength()* getWidth()*getHeight();
        return volume;
    }
    public double calculateDensity() // Calculating density 
    {
      try        // if volume is 0.0 means divison by zero happens the throw the exception 
      {
        if (calculateVolume()== 0.0) 
        {
            throw new ArithmeticException("Division by zero attempted.");
        }
        double density = weight / calculateVolume();
        return density;
      } 
      catch (ArithmeticException ae) // catching the exception and pritning the message along with returning 0.00 as density. 
      {
          
        System.out.println(ae.getMessage());
        return 0.00;
    }
   }
     public boolean isHeavy() 
                    // if Density is greater than equal to 10.00 lbs./cubic ft then box is heavy i.e true and false otherwise
   {
    
    if (calculateVolume()== 0.0)   /* just for not throwing the exception here if volume is equal to 0.0 and it will not 
                                      call calculate density()and not throw an exception and return false instead.
                                      no need to call and check for density because it will be zero. */
    {
        return false; 
    }
    else if(calculateDensity()>=10.00)
    {
        return true;
    }
    
    return false;
    
    }
   public boolean isLightweight() 
            // if density is smaller than and equal to 0.10 lbs./cubic ft then box is lightweight i.e true and false otherwise
    {
    
      if(calculateVolume()==0.00)  /*if volume is equal to 0.0 and it will not call calculate density()and not 
                                    throw an exception and return true instead.
                                    no need to call and check for density because it will be zero. */
      {
          return true;
      }
       if(calculateDensity()<=0.10)
      {
        return true;
      }
    
    return false;
    }
}
