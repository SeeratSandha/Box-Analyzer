


                                       /**************************************************************
                                        ***  Project Name : CS 200 Programming Assignment 2 (HW2)  ***
                                        ***  Author       : Seerat Sandha                          ***
                                        ***  Date         : 10/15/2023                             ***
                                        **************************************************************/
import java.util.Scanner;
public class Tester extends Box
{
    public static void main(String[] args)
    {
        Scanner scnr = new Scanner(System.in);

        System.out.printf("Enter the length in feet: ");
        double length = scnr.nextDouble();
        
        System.out.printf("Enter the width in feet: ");
        double width = scnr.nextDouble();

        System.out.printf("Enter the height in feet: ");
        double height = scnr.nextDouble();

        System.out.printf("Enter the weight in pounds: ");
        double weight = scnr.nextDouble();
          
        
        Box box = new Box(length, width, height,weight);
        // calling the methods via method accessor. 
        box.setLength(length);
        box.setWidth(width);
        box.setHeight(height);
        box.setWeight(weight);
        
        

        System.out.printf("The volume of the box is %.2f cubic feet.%n", box.calculateVolume());
        System.out.printf("The density of the box is %.2f lbs./cubic ft.%n", box.calculateDensity());
        
        /*using if and else statements( Branches) to check the conditons and printing the desired output on the screen using the
        printf */
        
        if (box.hasASquare())  
        {
            System.out.printf("At least one side of the box is square.%n");
        } 
        else 
        {
            System.out.printf("No sides of the box are square.%n");
        }

        if (box.isACube())
        {
            System.out.printf("The box is a cube.%n");
        } 
        else
        {
            System.out.printf("The box is not a cube.%n");
        }

        if (box.isHeavy()) 
        {
            System.out.printf("The box is heavy.%n");
        } 
        else 
        {
            System.out.printf("The box is not heavy.%n");
        }

        if (box.isLightweight()) 
        {
            System.out.printf("The box is lightweight.%n");
        } 
        else 
        {
            System.out.printf("The box is not lightweight.%n");
        }
    }
}
